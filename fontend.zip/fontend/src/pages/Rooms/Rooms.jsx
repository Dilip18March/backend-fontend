import React from 'react'

const Rooms = () => {
		return (
			<div>
				Rooms components
						
				</div>
		)
}

export default Rooms
