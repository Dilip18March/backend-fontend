import React from 'react'

const StepUsername = ({onNext}) => {
	return (
			<>
				<div>
						StepUsername components
			</div>
			
			<button onClick={onNext}></button>
			</>
		)
}

export default StepUsername
