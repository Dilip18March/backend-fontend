import React from 'react'

const StepName = ({onNext}) => {
	return (
			<>
				<div>
						StepName components
			</div>
			
			<button onClick={onNext}></button>
			</>
		)
}

export default StepName
