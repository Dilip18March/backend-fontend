import React from 'react'

const Activate = () => {
		return (
			<div>
				Activate components
						
				</div>
		)
}

export default Activate
